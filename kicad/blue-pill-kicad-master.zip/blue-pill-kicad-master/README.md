# blue-pill-kicad
footprint and symbol

hole diameter is 0.9mm
