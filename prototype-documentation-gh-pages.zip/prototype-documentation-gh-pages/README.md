prototype-documentation
=======================

DIY Instructions on how to make your own Primo prototype.

Get Started Here: [http://docs.primo.io](http://docs.primo.io)